package com.rydlo.entities;

public enum BookingStatus {

	BOOKED,ONGOING,COMPLETED,CANCELLED;
}
