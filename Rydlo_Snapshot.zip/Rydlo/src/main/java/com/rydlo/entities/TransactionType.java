package com.rydlo.entities;

public enum TransactionType {
    BOOKING_PAYMENT,
    EXTRA_KM_PAYMENT,
    REFUND
}