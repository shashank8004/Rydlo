package com.rydlo.entities;

public enum Role {

	ROLE_CUSTOMER,ROLE_OWNER,ROLE_ADMIN
}
