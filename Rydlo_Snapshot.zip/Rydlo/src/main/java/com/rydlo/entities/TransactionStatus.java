package com.rydlo.entities;

public enum TransactionStatus {

	INITIATED,SUCCESSFUL,FAILED,PENDING
}
