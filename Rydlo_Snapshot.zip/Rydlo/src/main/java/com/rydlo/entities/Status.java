package com.rydlo.entities;

public enum Status {

	ACTIVE,INACTIVE
}
