package com.rydlo.entities;

public enum BikeType {
 ELECTRIC,SCOOTY,SPORTS
}
