package com.rydlo.custom_exception;

public class IllegalArgumentException extends RuntimeException {

	public IllegalArgumentException() {
		// TODO Auto-generated constructor stub
	}

	public IllegalArgumentException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public IllegalArgumentException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public IllegalArgumentException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public IllegalArgumentException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
